"""
SimpleCompletion: نموذج تجريبي يُحاول "ملأ" الأسنان عبر انعكاس النقاط
هذه طريقة بدائية للاختبار. استبدلها بنموذج مدرّب لاحقاً.
"""
import numpy as np
from scipy.spatial import cKDTree

class SimpleCompletion:
    def __init__(self, mirror_axis=0):
        # mirror_axis: 0 -> X axis (يعتبر منتصف الفك عند x=0)
        self.axis = mirror_axis

    def complete(self, pts: np.ndarray, target_n=8192):
        """
        pts: (N,3) partial point cloud
        طريقة بسيطة: نأخذ نقاط الأصل، ننسخها ونعاكسها حول محور محدد لإعطاء مظهر مكتمل.
        ثم نستخدم kNN لملء ونعيد sample إلى حجم target_n.
        """
        if pts.size == 0:
            return pts
        # create mirror
        mirror = pts.copy()
        mirror[:, self.axis] *= -1.0
        combined = np.vstack([pts, mirror])

        # optional: jitter small noise to avoid perfect duplicates
        jitter = np.random.normal(scale=1e-3, size=combined.shape).astype('float32')
        combined = combined + jitter

        # if too many points, downsample
        if combined.shape[0] > target_n:
            idx = np.random.choice(combined.shape[0], target_n, replace=False)
            sampled = combined[idx]
        else:
            # upsample via nearest neighbor sampling
            tree = cKDTree(combined)
            extra = target_n - combined.shape[0]
            if extra > 0:
                # sample random points near existing ones
                idxs = tree.query(np.random.randn(extra, 3), k=1)[1]
                sampled = np.vstack([combined, combined[idxs]])
            else:
                sampled = combined
        return sampled.astype('float32')