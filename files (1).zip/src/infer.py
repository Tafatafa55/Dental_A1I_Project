"""
CLI: تحويل ملف STL فارغ -> STL مملوء باستخدام نفس pipeline كـ API
"""
import argparse
from utils.mesh_utils import stl_to_pointcloud, pts_to_mesh_and_save
from models.simple_completion import SimpleCompletion
import os

def infer_file(input_stl, output_stl):
    pts = stl_to_pointcloud(input_stl, n_points=4096)
    model = SimpleCompletion()
    pred = model.complete(pts, target_n=8192)
    pts_to_mesh_and_save(pred, output_stl)
    print("Saved:", output_stl)

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--input', required=True)
    p.add_argument('--output', required=True)
    args = p.parse_args()
    infer_file(args.input, args.output)