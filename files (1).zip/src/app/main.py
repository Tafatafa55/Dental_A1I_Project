from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
import os
from pathlib import Path
from utils.mesh_utils import stl_to_pointcloud, pts_to_mesh_and_save
from models.simple_completion import SimpleCompletion
import numpy as np

app = FastAPI(title="Dental AI - STL Completion")

BASE_DIR = Path(__file__).resolve().parents[1]
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Serve a simple static HTML UI
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")

@app.get("/", response_class=HTMLResponse)
async def index():
    return (BASE_DIR / "static" / "index.html").read_text(encoding="utf-8")

@app.post("/upload/")
async def upload_stl(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".stl"):
        raise HTTPException(status_code=400, detail="Only .stl files are supported")
    in_path = UPLOAD_DIR / file.filename
    with open(in_path, "wb") as f:
        content = await file.read()
        f.write(content)

    # Preprocess: sample pointcloud
    pts = stl_to_pointcloud(str(in_path), n_points=4096)  # numpy array (N,3)

    # Inference: run simple completion model
    model = SimpleCompletion()
    completed_pts = model.complete(pts)  # numpy (M,3)

    # Reconstruct mesh and save STL
    out_name = f"filled_{file.filename}"
    out_path = OUTPUT_DIR / out_name
    pts_to_mesh_and_save(completed_pts, str(out_path))

    return {"output_stl": f"/download/{out_name}"}

@app.get("/download/{filename}")
def download(filename: str):
    p = OUTPUT_DIR / filename
    if not p.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(str(p), media_type="application/sla", filename=filename)