import numpy as np
import open3d as o3d
import os

def stl_to_pointcloud(stl_path, n_points=4096):
    mesh = o3d.io.read_triangle_mesh(stl_path)
    if mesh.is_empty():
        raise RuntimeError("Empty mesh or cannot read STL")
    pcd = mesh.sample_points_uniformly(number_of_points=n_points)
    pts = np.asarray(pcd.points).astype('float32')
    return pts

def pts_to_mesh_and_save(points, out_path, poisson_depth=8):
    # points: numpy (N,3)
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    # estimate normals required for Poisson
    pcd.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=1.0, max_nn=30))
    try:
        mesh, densities = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(pcd, depth=poisson_depth)
        # crop by density to remove low-density parts
        densities = np.asarray(densities)
        if densities.size > 0:
            density_threshold = np.quantile(densities, 0.01)
            vertices_to_keep = densities > density_threshold
            mesh.remove_vertices_by_mask(~vertices_to_keep)
    except Exception as e:
        # fallback: create small mesh via alpha shape
        mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_alpha_shape(pcd, alpha=0.05)
    # ensure watertight-ish normals
    mesh.compute_vertex_normals()
    o3d.io.write_triangle_mesh(out_path, mesh)
    return out_path